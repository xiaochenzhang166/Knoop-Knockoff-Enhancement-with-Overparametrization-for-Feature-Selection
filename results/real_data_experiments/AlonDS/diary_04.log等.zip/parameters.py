# 设置所有程序中的参数
max_topK = 100
data_dim = 2000 # 1~2000 in Alon dataset
split = 0.4 # test size / total size
knockoff_hier = 3